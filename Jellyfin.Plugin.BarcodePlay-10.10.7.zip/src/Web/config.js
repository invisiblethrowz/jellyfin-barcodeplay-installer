(function(){
  const $ = (s)=>document.querySelector(s);
  const status = $('#status');
  const barcode = $('#barcode');
  const session = $('#session');
  const send = $('#send');
  const lastMatch = $('#lastMatch');
  const tbody = $('#history tbody');
  const refresh = $('#refresh');

  function addHistory(entry){
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${new Date().toLocaleString()}</td>
      <td><code>${entry.code}</code></td>
      <td>${entry.ok ? '<span class="pill">OK</span>' : '<span class="pill" style="background:#a002;">ERR</span>'}</td>
      <td>${entry.msg || ''}</td>`;
    tbody.prepend(tr);
  }

  async function postScan(code){
    status.textContent = 'Submitting…';
    try{
      const url = `${window.location.origin}/BarcodePlay/scan`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, sessionId: session.value || null })
      });
      const data = await res.json();
      if(res.ok){
        status.innerHTML = `<span class="ok">Playing: ${data.itemName || data.itemId}</span>`;
        lastMatch.innerHTML = `<strong>${data.title || 'Unknown'}</strong> ${data.year ? '('+data.year+')' : ''}<br/>
          <small>Library: ${data.itemName || data.itemId}</small>`;
        addHistory({code, ok:true, msg:`Playing ${data.itemName || data.itemId}`});
      } else {
        status.innerHTML = `<span class="${data.status==='no_session' ? 'warn' : 'err'}">${data.message || 'Error'}</span>`;
        addHistory({code, ok:false, msg:data.message || 'Error'});
      }
    } catch(e){
      status.innerHTML = `<span class="err">${e}</span>`;
      addHistory({code, ok:false, msg:String(e)});
    } finally {
      barcode.value='';
      barcode.focus();
    }
  }

  send.addEventListener('click', () => {
    if(barcode.value.trim()) postScan(barcode.value.trim());
  });

  barcode.addEventListener('keydown', (e) => {
    if(e.key === 'Enter' && barcode.value.trim()){
      postScan(barcode.value.trim());
    }
  });

  refresh.addEventListener('click', () => {
    alert('Tip: Session selection is configured in the plugin settings or passed per-scan above. (Enumerating sessions from the browser is not exposed here for now.)');
  });

  barcode.focus();
})();