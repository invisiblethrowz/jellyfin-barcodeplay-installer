using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.BarcodePlay.Services
{
    public class BarcodeLookupService : IBarcodeLookupService
    {
        private static readonly HttpClient _http = new HttpClient();
        private readonly ILogger<BarcodeLookupService> _log;

        public BarcodeLookupService(ILogger<BarcodeLookupService> log)
        {
            _log = log;
        }

        public async Task<BarcodeLookupResult?> LookupAsync(string barcode, string? tmdbApiKey, string? upcApiKey, CancellationToken ct)
        {
            _log.LogInformation("[BarcodeLookup] Looking up UPC/EAN {Barcode}", barcode);

            string upcUrl = !string.IsNullOrWhiteSpace(upcApiKey)
                ? $"https://api.upcitemdb.com/prod/v1/lookup?upc={Uri.EscapeDataString(barcode)}&apikey={Uri.EscapeDataString(upcApiKey)}"
                : $"https://api.upcitemdb.com/prod/trial/lookup?upc={Uri.EscapeDataString(barcode)}";

            try
            {
                using var upcResp = await _http.GetAsync(upcUrl, ct).ConfigureAwait(false);
                var ok = upcResp.IsSuccessStatusCode;
                var body = await upcResp.Content.ReadAsStringAsync(ct).ConfigureAwait(false);
                _log.LogDebug("[BarcodeLookup] UPCitemdb status {Status}, body: {Body}", (int)upcResp.StatusCode, body);

                if (!ok) return null;

                using var upcDoc = JsonDocument.Parse(body);
                if (!upcDoc.RootElement.TryGetProperty("items", out var items) || items.ValueKind != JsonValueKind.Array || items.GetArrayLength() == 0)
                {
                    _log.LogWarning("[BarcodeLookup] UPCitemdb returned no items for {Barcode}", barcode);
                    return null;
                }

                var item = items[0];
                var rawTitle = item.TryGetProperty("title", out var tEl) ? tEl.GetString() : null;

                if (string.IsNullOrWhiteSpace(rawTitle))
                {
                    _log.LogWarning("[BarcodeLookup] UPCitemdb had empty title for {Barcode}", barcode);
                    return null;
                }

                if (string.IsNullOrWhiteSpace(tmdbApiKey))
                {
                    _log.LogInformation("[BarcodeLookup] No TMDb key; returning UPC title only: {Title}", rawTitle);
                    return new BarcodeLookupResult(rawTitle, null);
                }

                var tmdbUrl = $"https://api.themoviedb.org/3/search/movie?api_key={Uri.EscapeDataString(tmdbApiKey!)}&query={Uri.EscapeDataString(rawTitle!)}";
                using var tmdbResp = await _http.GetAsync(tmdbUrl, ct).ConfigureAwait(false);
                var tmdbBody = await tmdbResp.Content.ReadAsStringAsync(ct).ConfigureAwait(false);
                _log.LogDebug("[BarcodeLookup] TMDb status {Status}, body: {Body}", (int)tmdbResp.StatusCode, tmdbBody);

                if (!tmdbResp.IsSuccessStatusCode)
                {
                    _log.LogWarning("[BarcodeLookup] TMDb non-success for title {Title}: {Status}", rawTitle, (int)tmdbResp.StatusCode);
                    return new BarcodeLookupResult(rawTitle, null);
                }

                using var tmdbDoc = JsonDocument.Parse(tmdbBody);
                if (!tmdbDoc.RootElement.TryGetProperty("results", out var results) || results.ValueKind != JsonValueKind.Array || results.GetArrayLength() == 0)
                {
                    _log.LogInformation("[BarcodeLookup] TMDb found no results for {Title}", rawTitle);
                    return new BarcodeLookupResult(rawTitle, null);
                }

                string? finalTitle = rawTitle;
                int? year = null;
                foreach (var r in results.EnumerateArray())
                {
                    var t = r.TryGetProperty("title", out var tt) ? tt.GetString() : null;
                    var rd = r.TryGetProperty("release_date", out var rdEl) ? rdEl.GetString() : null;
                    if (!string.IsNullOrWhiteSpace(rd) && rd!.Length >= 4 && int.TryParse(rd.Substring(0, 4), out var y))
                        year = y;

                    if (!string.IsNullOrWhiteSpace(t) && string.Equals(t, rawTitle, StringComparison.OrdinalIgnoreCase))
                    {
                        finalTitle = t;
                        break;
                    }
                    if (finalTitle == rawTitle)
                        finalTitle = t ?? rawTitle;
                }

                _log.LogInformation("[BarcodeLookup] Resolved title '{Title}' year {Year}", finalTitle, year);
                return new BarcodeLookupResult(finalTitle, year);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "[BarcodeLookup] Exception during lookup for {Barcode}", barcode);
                throw;
            }
        }
    }
}
