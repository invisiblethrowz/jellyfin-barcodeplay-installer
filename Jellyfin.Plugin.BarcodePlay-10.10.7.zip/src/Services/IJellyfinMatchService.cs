using System.Threading;
using System.Threading.Tasks;

namespace Jellyfin.Plugin.BarcodePlay.Services
{
    public interface IJellyfinMatchService
    {
        Task<(string? ItemId, string? ItemName)> FindMovieAsync(string title, int? year, bool preferExact, CancellationToken ct);
        Task<bool> PlayAsync(string itemId, string? sessionId, CancellationToken ct);
    }
}
