using System.Threading;
using System.Threading.Tasks;

namespace Jellyfin.Plugin.BarcodePlay.Services
{
    public record BarcodeLookupResult(string? Title, int? Year);

    public interface IBarcodeLookupService
    {
        Task<BarcodeLookupResult?> LookupAsync(string barcode, string? tmdbApiKey, string? upcApiKey, CancellationToken ct);
    }
}
