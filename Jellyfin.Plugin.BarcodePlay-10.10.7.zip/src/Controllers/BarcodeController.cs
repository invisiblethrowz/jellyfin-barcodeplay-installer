using System.ComponentModel.DataAnnotations;
using System.Threading;
using System.Threading.Tasks;
using Jellyfin.Plugin.BarcodePlay.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.BarcodePlay.Controllers
{
    [ApiController]
    public class BarcodeController : ControllerBase
    {
        private readonly Plugin _plugin;
        private readonly IBarcodeLookupService _barcodeLookup;
        private readonly IJellyfinMatchService _match;
        private readonly ILogger<BarcodeController> _log;

        public BarcodeController(Plugin plugin, IBarcodeLookupService barcodeLookup, IJellyfinMatchService match, ILogger<BarcodeController> log)
        {
            _plugin = plugin;
            _barcodeLookup = barcodeLookup;
            _match = match;
            _log = log;
        }

        public record ScanRequest([Required] string Code, string? SessionId);
        public record ScanResponse(string Status, string? ItemId = null, string? ItemName = null, string? Message = null, string? Title = null, int? Year = null);

        [HttpPost]
        [Route("Plugin/BarcodePlay/Barcode")]
        [Route("BarcodePlay/scan")]
        [Produces("application/json")]
        public async Task<ActionResult<ScanResponse>> Post([FromBody] ScanRequest req, CancellationToken ct)
        {
            if (!ModelState.IsValid)
                return BadRequest(new ScanResponse("error", Message: "Invalid payload"));

            _log.LogInformation("[API] Scan received: {Barcode} (session override: {Session})", req.Code, req.SessionId);

            var cfg = _plugin.Configuration;
            var lookup = await _barcodeLookup.LookupAsync(req.Code, cfg.TmdbApiKey, cfg.UpcItemDbApiKey, ct);
            if (lookup is null || string.IsNullOrWhiteSpace(lookup.Title))
            {
                _log.LogWarning("[API] Barcode not recognized: {Barcode}", req.Code);
                return NotFound(new ScanResponse("not_found", Message: "Barcode not recognized"));
            }

            var (itemId, itemName) = await _match.FindMovieAsync(lookup.Title!, lookup.Year, cfg.PreferExactTitleMatch, ct);
            if (itemId is null)
            {
                return NotFound(new ScanResponse("not_found", Title: lookup.Title, Year: lookup.Year, Message: $"No library match for '{lookup.Title}' ({lookup.Year?.ToString() ?? "n/a"})"));
            }

            var sessionId = req.SessionId ?? cfg.DefaultSessionId;
            var played = await _match.PlayAsync(itemId, sessionId, ct);
            if (!played)
            {
                return StatusCode(409, new ScanResponse("no_session", itemId, itemName, "No active/selected session to play on", lookup.Title, lookup.Year));
            }

            return Ok(new ScanResponse("playing", itemId, itemName, Title: lookup.Title, Year: lookup.Year));
        }
    }
}
