# Jellyfin.Plugin.BarcodePlay (Jellyfin 10.10.7)

Scan a DVD/Blu-ray UPC/EAN and play the matching movie on your Jellyfin client.

## Features
- HTTP endpoints:
  - `POST /Plugin/BarcodePlay/Barcode`  (legacy path kept for compatibility)
  - `POST /BarcodePlay/scan`            (short path)
- Fancy Dashboard page (Plugins → Barcode Play) with:
  - live scan input
  - scan history
  - last match preview
  - status + error messages
- UPC → Title/Year via UPCitemdb (API key optional; trial endpoint available)
- Title → Year refinement via TMDb (API key required for best results)
- Library match + immediate playback on selected/most-recent session
- Verbose logging for first-time setup and troubleshooting

## Build
```bash
cd src
dotnet restore
dotnet build -c Release
```

Copy `bin/Release/net8.0/Jellyfin.Plugin.BarcodePlay.dll` into your Jellyfin plugins folder (create `plugins/BarcodePlay/`), then restart Jellyfin 10.10.7.

## Configure
Dashboard → Plugins → **Barcode Play**:
- TMDb API Key
- UPCitemdb API Key (optional; leave blank to use trial)
- Default Session Id (optional)
- Prefer exact title match (toggle)

## Test the API
```bash
curl -sS -X POST http://<jellyfin-host>:8096/BarcodePlay/scan \  -H "Content-Type: application/json" \  -d '{ "code": "012345678905" }' | jq .
```
