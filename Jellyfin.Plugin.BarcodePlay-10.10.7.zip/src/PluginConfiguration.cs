using MediaBrowser.Model.Plugins;

namespace Jellyfin.Plugin.BarcodePlay
{
    public class PluginConfiguration : BasePluginConfiguration
    {
        public string? TmdbApiKey { get; set; } = "YOUR_TMDB_KEY_HERE";
        public string? UpcItemDbApiKey { get; set; } = "YOUR_UPCITEMDB_KEY_HERE";
        public string? DefaultSessionId { get; set; }
        public bool PreferExactTitleMatch { get; set; } = true;
    }
}
