using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediaBrowser.Controller.Entities.Movies;
using MediaBrowser.Controller.Library;
using MediaBrowser.Controller.Session;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.BarcodePlay.Services
{
    public class JellyfinMatchService : IJellyfinMatchService
    {
        private readonly ILibraryManager _libraryManager;
        private readonly ISessionManager _sessionManager;
        private readonly ILogger<JellyfinMatchService> _log;

        public JellyfinMatchService(ILibraryManager libraryManager, ISessionManager sessionManager, ILogger<JellyfinMatchService> log)
        {
            _libraryManager = libraryManager;
            _sessionManager = sessionManager;
            _log = log;
        }

        public Task<(string? ItemId, string? ItemName)> FindMovieAsync(string title, int? year, bool preferExact, CancellationToken ct)
        {
            var movies = _libraryManager.GetItemList(new InternalItemsQuery
            {
                IncludeItemTypes = new[] { nameof(Movie) },
                Recursive = true
            }).OfType<Movie>();

            if (preferExact)
            {
                var exact = movies.FirstOrDefault(m =>
                    string.Equals(m.Name?.Trim(), title?.Trim(), StringComparison.OrdinalIgnoreCase) &&
                    (!year.HasValue || m.ProductionYear == year));
                if (exact != null)
                {
                    _log.LogInformation("[Match] Exact match: {Title} ({Year}) → {Id}", exact.Name, exact.ProductionYear, exact.Id);
                    return Task.FromResult((exact.Id.ToString("N"), exact.Name));
                }
            }

            var fuzzy = movies
                .Select(m => new { m, score = Score(m, title, year) })
                .OrderByDescending(x => x.score)
                .FirstOrDefault();

            if (fuzzy?.score > 0)
            {
                _log.LogInformation("[Match] Fuzzy match: {Title} ({Year}) score {Score} → {Id}",
                    fuzzy.m.Name, fuzzy.m.ProductionYear, fuzzy.score, fuzzy.m.Id);
                return Task.FromResult((fuzzy.m.Id.ToString("N"), fuzzy.m.Name));
            }

            _log.LogWarning("[Match] No library match for '{Title}' ({Year})", title, year);
            return Task.FromResult<(string?, string?)>((null, null));
        }

        public async Task<bool> PlayAsync(string itemId, string? sessionId, CancellationToken ct)
        {
            var session = sessionId != null
                ? _sessionManager.Sessions.FirstOrDefault(s => s.Id.Equals(sessionId, StringComparison.OrdinalIgnoreCase))
                : _sessionManager.Sessions.OrderByDescending(s => s.LastActivityDate).FirstOrDefault();

            if (session == null)
            {
                _log.LogWarning("[Play] No active session found (requested SessionId={Req})", sessionId);
                return false;
            }

            var request = new PlayRequest
            {
                ItemIds = new[] { Guid.Parse(itemId) },
                StartPositionTicks = 0,
                PlayCommand = PlayCommand.PlayNow
            };

            _log.LogInformation("[Play] Sending play for item {ItemId} to session {Session}", itemId, session.Id);
            await _sessionManager.SendPlayCommand(session, request, ct).ConfigureAwait(false);
            return true;
        }

        private static int Score(Movie m, string title, int? year)
        {
            int s = 0;
            if (!string.IsNullOrWhiteSpace(title))
            {
                if (m.Name?.Equals(title, StringComparison.OrdinalIgnoreCase) == true) s += 100;
                else if (m.Name?.IndexOf(title, StringComparison.OrdinalIgnoreCase) >= 0) s += 50;
            }
            if (year.HasValue && m.ProductionYear == year) s += 25;
            return s;
        }
    }

    public enum PlayCommand { PlayNow = 0 }
    public class PlayRequest
    {
        public Guid[]? ItemIds { get; set; }
        public long StartPositionTicks { get; set; }
        public PlayCommand PlayCommand { get; set; }
    }
}
